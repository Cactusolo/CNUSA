#!/bin/bash

for site in `cat site_list`; do
	echo $site
	echo "Species_name,Lat,Lon" >${site}_tree_sample_noNA.csv
	grep -Fw $site plant_info_2019_0223_Miao.csv|awk -F ',' '{print$5"_"$6","$7","$8}'|grep -v ",," >>${site}_tree_sample_noNA.csv
	wc -l ${site}_tree_sample_noNA.csv
done


